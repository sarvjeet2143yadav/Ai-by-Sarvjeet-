SARVJEET AI - Android APK starter project

यह Android Studio project है। यह अभी APK नहीं है, बल्कि APK बनाने के लिए source project है।

महत्वपूर्ण:
1. असली AI के लिए सुरक्षित backend server और API provider की जरूरत होगी।
2. API key को इस Android project या HTML/JavaScript में कभी न डालें।
3. API account, billing और server secrets की सेटिंग माता-पिता/अभिभावक की मदद से करें।
4. इस project में AI_SERVER_URL अभी placeholder है। Backend बनने और HTTPS URL मिलने के बाद इसे बदलना होगा।

APK बनाने का आसान रास्ता:
- इस ZIP को GitHub repository में upload करें।
- GitHub Actions में Android Build workflow चलाएँ।
- Workflow पूरा होने पर Actions > workflow run > Artifacts से debug APK लें।
- फोन पर APK install करने से पहले अभिभावक से जाँच कराएँ।

जरूरत: Android build environment / GitHub Actions. Acode अकेले APK compile नहीं करता।
